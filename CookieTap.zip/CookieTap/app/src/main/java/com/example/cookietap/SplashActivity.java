package com.example.cookietap;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Timer;
import java.util.TimerTask;

public class SplashActivity extends AppCompatActivity {

    int time = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        TextView lblPercentage = (TextView) findViewById(R.id.lblPercentage);

        ProgressBar pgbSplash = (ProgressBar) findViewById(R.id.pgbSplash);

        Timer timer = new Timer();
        TimerTask timerTask;
        timerTask = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if(time < 100){
                            time += 1;
                            pgbSplash.setProgress(time);
                            lblPercentage.setText(time + "%");
                        }
                    }
                });
            }
        };
        timer.scheduleAtFixedRate(timerTask, 0, 100);
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                timer.cancel();
                Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        }, 10000);
    }
}