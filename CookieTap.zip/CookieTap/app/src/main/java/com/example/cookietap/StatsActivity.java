package com.example.cookietap;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.FileOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class StatsActivity extends AppCompatActivity {

    String username = "";
    int total = 0;
    String time = "";
    int cookies = 0;
    int cookiesSpent = 0;
    FileOutputStream outputStream;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);

        Button btnSubmit = (Button) findViewById(R.id.btnSubmit);

        TextView lblTime = (TextView) findViewById(R.id.lblTimeShow);
        TextView lblCookies = (TextView) findViewById(R.id.lblCookiesShow);
        TextView lblCookiesSpent = (TextView) findViewById(R.id.lblCookiesSpentShow);
        TextView lblCookiesTotal = (TextView) findViewById(R.id.lblCookiesTotalShow);
        TextView lblError = (TextView) findViewById(R.id.lblError);

        EditText txtUsername = (EditText) findViewById(R.id.txtUsername);

        time = getIntent().getStringExtra("time");
        cookies = getIntent().getIntExtra("cookies", 0);
        cookiesSpent = getIntent().getIntExtra("cookiesSpent", 0);
        lblTime.setText(time);
        lblCookies.setText(String.valueOf(cookies));
        lblCookiesSpent.setText(String.valueOf(cookiesSpent));
        total = cookies + cookiesSpent;
        lblCookiesTotal.setText(String.valueOf(total));

        btnSubmit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                username = txtUsername.getText().toString();
                if(username.matches("")){
                    lblError.setText("Please enter a username");
                }
                else if(username.length() < 5){
                    lblError.setText("Username must be at least 5 characters long");
                }
                else if(username.length() > 10){
                    lblError.setText("Username cannot be longer than 10 characters");
                }
                else{
                    AlertDialog.Builder builder = new AlertDialog.Builder(StatsActivity.this);
                    builder.setTitle("Submit to Leaderboard?");
                    builder.setMessage("Do you want to submit? This will reset your current stats and add them to the leaderboard");
                    builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.dismiss();
                            try{
                                outputStream = openFileOutput("leaderboard", Context.MODE_APPEND);

                                outputStream.write(username.getBytes());
                                outputStream.write("\n".getBytes());
                                outputStream.write(String.valueOf(total).getBytes());
                                outputStream.write("\n".getBytes());

                                outputStream.close();
                                SharedPreferences settings = getSharedPreferences("pref", 0);
                                SharedPreferences.Editor editor = settings.edit();
                                editor.clear();
                                editor.apply();
                                lblError.setText("Stats submitted!");

                            }
                            catch(Exception ex)
                            {
                                lblError.setText("Failed to submit");
                            }
                        }
                    });
                    builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.dismiss();
                        }
                    });
                    AlertDialog alert = builder.create();
                    alert.show();
                }
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.stats_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.game){
            Toast.makeText(StatsActivity.this, "Returning To Game", Toast.LENGTH_LONG).show();
            Intent leaderboard = new Intent(StatsActivity.this, MainActivity.class);
            startActivity(leaderboard);
            return true;
        }
        else if(item.getItemId() == R.id.leaderboard){
            Toast.makeText(StatsActivity.this, "Leaderboard", Toast.LENGTH_LONG).show();
            Intent leaderboard = new Intent(StatsActivity.this, LeaderboardActivity.class);
            leaderboard.putExtra("time", time);
            leaderboard.putExtra("cookies", cookies);
            leaderboard.putExtra("cookiesSpent", cookiesSpent);
            startActivity(leaderboard);
            return true;
        }
        else if(item.getItemId() == R.id.setReminder){
            Toast.makeText(StatsActivity.this, "Setting reminder", Toast.LENGTH_LONG).show();
            GregorianCalendar gc = new GregorianCalendar();
            gc.add(Calendar.DATE, 1);
            String date = new SimpleDateFormat("yyyy-MM-dd").format(gc.getTime());
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date mDate = null;
            try {
                mDate = sdf.parse(date);
            } catch (ParseException e) {
                e.printStackTrace();
            }

            Calendar cal = Calendar.getInstance();
            cal.setTime(mDate);
            cal.set(Calendar.HOUR_OF_DAY, 8);
            cal.set(Calendar.MINUTE, 00);
            Intent intent = new Intent(Intent.ACTION_EDIT);
            intent.setType("vnd.android.cursor.item/event");
            intent.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, cal.getTimeInMillis());
            intent.putExtra(CalendarContract.EXTRA_EVENT_ALL_DAY, false);
            intent.putExtra(CalendarContract.Events.TITLE, "Play Cookie Tap!");
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            return true;
        }
        else if(item.getItemId() == R.id.reset){
            AlertDialog.Builder builder = new AlertDialog.Builder(StatsActivity.this);
            builder.setTitle("Reset Progress?");
            builder.setMessage("Are you sure you want to reset? Progress won't automatically be added to the leaderboard");
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.dismiss();
                    Toast.makeText(StatsActivity.this, "Resetting", Toast.LENGTH_LONG).show();
                    SharedPreferences settings = getSharedPreferences("pref", 0);
                    SharedPreferences.Editor editor = settings.edit();
                    editor.clear();
                    editor.apply();
                    Intent reset = new Intent(StatsActivity.this, SplashActivity.class);
                    startActivity(reset);
                }
            });
            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.dismiss();
                }
            });
            AlertDialog alert = builder.create();
            alert.show();
            return true;
        }
        else{
            return super.onOptionsItemSelected(item);
        }
    }
}