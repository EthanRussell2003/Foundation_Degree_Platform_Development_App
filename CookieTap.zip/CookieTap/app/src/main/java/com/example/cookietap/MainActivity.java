package com.example.cookietap;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    float time = 0;
    int timeAutoTapper = 0;
    int timeGranny = 0;
    int cookies = 0;
    int cookiesSpent = 0;
    int tapPower = 1;
    int tapPowerPrice = 10;
    int autoTappers = 0;
    int autoTapperPrice = 100;
    int autoTapInterval = 10;
    int autoTapIntervalPrice = 200;
    int granny = 0;
    int grannyPrice = 200;
    boolean autoTapFlag = false;
    boolean grannyFlag = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageButton imgBtnCookie = (ImageButton) findViewById(R.id.imgBtnCookie);

        Button btnTapPower = (Button) findViewById(R.id.btnTapPower);
        Button btnAutoTapper = (Button) findViewById(R.id.btnAutoTapper);
        Button btnAutoTapInterval = (Button) findViewById(R.id.btnAutoTapInterval);
        Button btnGranny = (Button) findViewById(R.id.btnGranny);

        TextView lblCookieNum = (TextView) findViewById(R.id.lblCookieNum);
        TextView lblTapPower = (TextView) findViewById(R.id.lblTapPower);
        TextView lblTimer = (TextView) findViewById(R.id.lblTimer);
        TextView lblTapPowerPrice = (TextView) findViewById(R.id.lblTapPowerPrice);
        TextView lblAutoTapPrice = (TextView) findViewById(R.id.lblAutoTapPrice);
        TextView lblAutoTap = (TextView) findViewById(R.id.lblAutoTap);
        TextView lblAutoTapInterval = (TextView) findViewById(R.id.lblAutoTapInterval);
        TextView lblAutoTapIntervalPrice = (TextView) findViewById(R.id.lblAutoTapIntervalPrice);
        TextView lblGranny = (TextView) findViewById(R.id.lblGranny);
        TextView lblGrannyPrice = (TextView) findViewById(R.id.lblGrannyPrice);

        ProgressBar pgbTapPower = (ProgressBar) findViewById(R.id.pgbTapPower);
        ProgressBar pgbAutoTap = (ProgressBar) findViewById(R.id.pgbAutoTap);
        ProgressBar pgbAutoTapInterval = (ProgressBar) findViewById(R.id.pgbAutoTapInterval);
        ProgressBar pgbGranny = (ProgressBar) findViewById(R.id.pgbGranny);

        pgbTapPower.setProgress(tapPower*5);

        RotateAnimation rotate = new RotateAnimation(0, 360, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);

        rotate.setDuration(80000);
        rotate.setRepeatCount(Animation.INFINITE);
        imgBtnCookie.startAnimation(rotate);

        Timer timer = new Timer();
        Timer timerGranny = new Timer();
        Timer timerAutoTapper = new Timer();
        TimerTask timerTask;
        timerTask = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        time += 0.01;
                        lblTimer.setText(getTimerText());
                        lblCookieNum.setText(String.valueOf(cookies));
                        lblTapPower.setText("Tap Power: " + tapPower + " out of 20");
                        lblTapPowerPrice.setText(String.valueOf(tapPowerPrice));
                        pgbTapPower.setProgress(tapPower*5);
                        lblAutoTap.setText("Auto-Tappers: " + autoTappers + " out of 20");
                        lblAutoTapPrice.setText(String.valueOf(autoTapperPrice));
                        pgbAutoTap.setProgress(autoTappers*5);
                        lblAutoTapInterval.setText("Auto-Tap Interval: " + autoTapInterval+ " seconds");
                        lblAutoTapIntervalPrice.setText(String.valueOf(autoTapIntervalPrice));
                        pgbAutoTapInterval.setProgress((10-autoTapInterval) * (100/9));
                        lblGranny.setText("Grannies: " + granny+ " out of 10");
                        lblGrannyPrice.setText(String.valueOf(grannyPrice));
                        pgbGranny.setProgress(granny * 10);

                        //Enable Tap Power Upgrades
                        if(cookies >= tapPowerPrice && tapPower < 20){
                            btnTapPower.setEnabled(true);
                        }
                        else {
                            btnTapPower.setEnabled(false);
                        }

                        //Enable Auto-Tapper Upgrades
                        if(cookies >= autoTapperPrice && autoTappers < 20){
                            btnAutoTapper.setEnabled(true);
                        }
                        else {
                            btnAutoTapper.setEnabled(false);
                        }

                        if(cookies >= autoTapIntervalPrice && autoTapInterval > 1){
                            btnAutoTapInterval.setEnabled(true);
                        }
                        else {
                            btnAutoTapInterval.setEnabled(false);
                        }

                        if(cookies >= grannyPrice && granny < 10){
                            btnGranny.setEnabled(true);
                        }
                        else {
                            btnGranny.setEnabled(false);
                        }
                    }
                });
            }
        };
        timer.scheduleAtFixedRate(timerTask, 0, 10);
        imgBtnCookie.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                cookies += tapPower;
            }
        });

        btnTapPower.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                cookies -= tapPowerPrice;
                cookiesSpent += tapPowerPrice;
                tapPower += 1;
                tapPowerPrice = (int) Math.round(tapPowerPrice * 1.4);
            }
        });

        btnAutoTapper.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                cookies -= autoTapperPrice;
                cookiesSpent += autoTapperPrice;
                autoTappers += 1;
                autoTapperPrice = (int) Math.round(autoTapperPrice * 1.2);

                if(autoTapFlag == false){
                    autoTapFlag = true;
                    TimerTask timerAutoTapperTask;
                    timerAutoTapperTask = new TimerTask() {
                        @Override
                        public void run() {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    timeAutoTapper += 1;

                                    if(timeAutoTapper % autoTapInterval == 0){
                                        cookies += (tapPower * autoTappers);
                                    }
                                }
                            });
                        }
                    };
                    timerAutoTapper.scheduleAtFixedRate(timerAutoTapperTask, 0, 1000);
                }
            }
        });

        btnAutoTapInterval.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                cookies -= autoTapIntervalPrice;
                cookiesSpent += autoTapIntervalPrice;
                autoTapInterval -= 1;
                autoTapIntervalPrice = (int) Math.round(autoTapIntervalPrice * 1.6);
            }
        });

        btnGranny.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                cookies -= grannyPrice;
                cookiesSpent += grannyPrice;
                granny += 1;
                grannyPrice = (int) Math.round(grannyPrice * 1.1);

                if(grannyFlag == false){
                    grannyFlag= true;
                    TimerTask timerGrannyTask;
                    timerGrannyTask = new TimerTask() {
                        @Override
                        public void run() {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    timeGranny += 1;

                                    if(timeGranny % 2 == 0){
                                        cookies += (granny * 50);
                                    }
                                }
                            });
                        }
                    };
                    timerGranny.scheduleAtFixedRate(timerGrannyTask, 0, 1000);
                }
            }
        });

        SharedPreferences settings = getSharedPreferences("pref", 0);

        time = settings.getFloat("time", time);
        timeAutoTapper = settings.getInt("timeAutoTapper", timeAutoTapper);
        timeGranny = settings.getInt("timeGranny", timeGranny);
        cookies = settings.getInt("cookies", cookies);
        cookiesSpent = settings.getInt("cookiesSpent", cookiesSpent);
        tapPower = settings.getInt("tapPower", tapPower);
        tapPowerPrice = settings.getInt("tapPowerPrice", tapPowerPrice);
        autoTappers = settings.getInt("autoTappers", autoTappers);
        autoTapperPrice = settings.getInt("autoTapperPrice", autoTapperPrice);
        autoTapInterval = settings.getInt("autoTapInterval", autoTapInterval);
        autoTapIntervalPrice = settings.getInt("autoTapIntervalPrice", autoTapIntervalPrice);
        granny = settings.getInt("granny", granny);
        grannyPrice = settings.getInt("grannyPrice", grannyPrice);
        autoTapFlag = settings.getBoolean("autoTapFlag", autoTapFlag);
        grannyFlag = settings.getBoolean("grannyFlag", grannyFlag);
        if(autoTapFlag == true){
            TimerTask timerAutoTapperTask;
            timerAutoTapperTask = new TimerTask() {
                @Override
                public void run() {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            timeAutoTapper += 1;

                            if(timeAutoTapper % autoTapInterval == 0){
                                cookies += (tapPower * autoTappers);
                            }
                        }
                    });
                }
            };
            timerAutoTapper.scheduleAtFixedRate(timerAutoTapperTask, 0, 1000);
        }
        if(grannyFlag == false){
            grannyFlag= true;
            TimerTask timerGrannyTask;
            timerGrannyTask = new TimerTask() {
                @Override
                public void run() {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            timeGranny += 1;

                            if(timeGranny % 2 == 0){
                                cookies += (granny * 50);
                            }
                        }
                    });
                }
            };
            timerGranny.scheduleAtFixedRate(timerGrannyTask, 0, 1000);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        SharedPreferences settings = getSharedPreferences("pref", 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putInt("cookies", cookies);
        editor.putInt("cookiesSpent", cookiesSpent);
        editor.putInt("tapPower", tapPower);
        editor.putInt("tapPowerPrice", tapPowerPrice);
        editor.putInt("autoTappers", autoTappers);
        editor.putInt("autoTapperPrice", autoTapperPrice);
        editor.putInt("autoTapInterval", autoTapInterval);
        editor.putInt("autoTapIntervalPrice", autoTapIntervalPrice);
        editor.putInt("granny", granny);
        editor.putInt("grannyPrice", grannyPrice);
        editor.putInt("timeAutoTapper", timeAutoTapper);
        editor.putInt("timeGranny", timeGranny);
        editor.putFloat("time", time);
        editor.putBoolean("autoTapFlag", autoTapFlag);
        editor.putBoolean("grannyFlag", grannyFlag);
        editor.commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_xml, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        TextView lblTimer = (TextView) findViewById(R.id.lblTimer);
        if(item.getItemId() == R.id.leaderboard){
            Toast.makeText(MainActivity.this, "Leaderboard", Toast.LENGTH_LONG).show();
            Intent leaderboard = new Intent(MainActivity.this, LeaderboardActivity.class);
            leaderboard.putExtra("time", lblTimer.getText().toString());
            leaderboard.putExtra("cookies", cookies);
            leaderboard.putExtra("cookiesSpent", cookiesSpent);
            startActivity(leaderboard);
            return true;
        }
        else if(item.getItemId() == R.id.stats){
            Toast.makeText(MainActivity.this, "Stats/Submit", Toast.LENGTH_LONG).show();
            Intent save = new Intent(MainActivity.this, StatsActivity.class);
            save.putExtra("time", lblTimer.getText().toString());
            save.putExtra("cookies", cookies);
            save.putExtra("cookiesSpent", cookiesSpent);
            startActivity(save);
            return true;
        }
        else if(item.getItemId() == R.id.setReminder){
            Toast.makeText(MainActivity.this, "Setting reminder", Toast.LENGTH_LONG).show();
            GregorianCalendar gc = new GregorianCalendar();
            gc.add(Calendar.DATE, 1);
            String date = new SimpleDateFormat("yyyy-MM-dd").format(gc.getTime());
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date mDate = null;
            try {
                mDate = sdf.parse(date);
            } catch (ParseException e) {
                e.printStackTrace();
            }

            Calendar cal = Calendar.getInstance();
            cal.setTime(mDate);
            cal.set(Calendar.HOUR_OF_DAY, 8);
            cal.set(Calendar.MINUTE, 00);
            Intent intent = new Intent(Intent.ACTION_EDIT);
            intent.setType("vnd.android.cursor.item/event");
            intent.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, cal.getTimeInMillis());
            intent.putExtra(CalendarContract.EXTRA_EVENT_ALL_DAY, false);
            intent.putExtra(CalendarContract.Events.TITLE, "Play Cookie Tap!");
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            return true;
        }
        else if(item.getItemId() == R.id.reset){
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Reset Progress?");
            builder.setMessage("Are you sure you want to reset? Progress won't automatically be added to the leaderboard");
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.dismiss();
                    Toast.makeText(MainActivity.this, "Resetting", Toast.LENGTH_LONG).show();
//                    SharedPreferences settings = getSharedPreferences("pref", 0);
//                    SharedPreferences.Editor editor = settings.edit();
//                    editor.clear();
//                    editor.apply();
                    time = 0;
                    timeAutoTapper = 0;
                    timeGranny = 0;
                    cookies = 0;
                    cookiesSpent = 0;
                    tapPower = 1;
                    tapPowerPrice = 10;
                    autoTappers = 0;
                    autoTapperPrice = 100;
                    autoTapInterval = 10;
                    autoTapIntervalPrice = 200;
                    granny = 0;
                    grannyPrice = 200;
                    autoTapFlag = false;
                    grannyFlag = false;
                    Intent reset = new Intent(MainActivity.this, SplashActivity.class);
                    startActivity(reset);
                }
            });
            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.dismiss();
                }
            });
            AlertDialog alert = builder.create();
            alert.show();
            return true;
        }
        else{
            return super.onOptionsItemSelected(item);
        }
    }

    private String getTimerText(){
        int rounded = (int) Math.round(time);
        int seconds = ((rounded % 86400) % 3600)%60;
        int minutes = ((rounded % 86400) % 3600)/60;
        int hours = ((rounded % 86400) / 3600);
        return formatTime(seconds, minutes, hours);
    }

    private String formatTime(int seconds, int minutes, int hours){
        return String.format("%02d",hours) + " : " + String.format("%02d", minutes) + " : " + String.format("%02d", seconds);
    }
}
