package com.example.cookietap;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class LeaderboardActivity extends AppCompatActivity {

    String time = "";
    int cookies = 0;
    int cookiesSpent = 0;
    int first = 0;
    int second = 0;
    int third = 0;
    int tempTotal = 0;
    String fName = "TBD";
    String sName = "TBD";
    String tName = "TBD";
    String tempName = "";
    InputStream inStream;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboard);
        time = getIntent().getStringExtra("time");
        cookies = getIntent().getIntExtra("cookies", 0);
        cookiesSpent = getIntent().getIntExtra("cookiesSpent", 0);

        TextView lblName1 = (TextView) findViewById(R.id.lblName1);
        TextView lblName2 = (TextView) findViewById(R.id.lblName2);
        TextView lblName3 = (TextView) findViewById(R.id.lblName3);
        TextView lblTotal1 = (TextView) findViewById(R.id.lblTotal1);
        TextView lblTotal2 = (TextView) findViewById(R.id.lblTotal2);
        TextView lblTotal3 = (TextView) findViewById(R.id.lblTotal3);

        try{
            inStream = openFileInput("leaderboard");

            if(inStream != null)
            {
                InputStreamReader inputReader = new InputStreamReader(inStream);
                BufferedReader buffReader = new BufferedReader(inputReader);
                String line = "";
                int track = 1;
                while((line=buffReader.readLine())!= null)
                {
                    if(track == 1){
                        tempName = line;
                        track += 1;
                    }
                    else {
                        track = 1;
                        tempTotal = Integer.parseInt(line);
                        if (tempTotal >= first) {
                            third = second;
                            tName = sName;
                            second = first;
                            sName = fName;
                            first = tempTotal;
                            fName = tempName;
                        } else if (tempTotal >= second) {
                            third = second;
                            tName = sName;
                            second = tempTotal;
                            sName = tempName;
                        } else if (tempTotal >= third) {
                            third = tempTotal;
                            tName = tempName;
                        }
                    }
                }

                lblName1.setText(fName);
                lblName2.setText(sName);
                lblName3.setText(tName);
                lblTotal1.setText(String.valueOf(first));
                lblTotal2.setText(String.valueOf(second));
                lblTotal3.setText(String.valueOf(third));

                inStream.close();
            }

        }
        catch(Exception ex)
        {
            lblName1.setText(fName);
            lblName2.setText(sName);
            lblName3.setText(tName);
            lblTotal1.setText(String.valueOf(first));
            lblTotal2.setText(String.valueOf(second));
            lblTotal3.setText(String.valueOf(third));
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.leaderboard_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.game){
            Toast.makeText(LeaderboardActivity.this, "Returning To Game", Toast.LENGTH_LONG).show();
            Intent leaderboard = new Intent(LeaderboardActivity.this, MainActivity.class);
            startActivity(leaderboard);
            return true;
        }
        else if(item.getItemId() == R.id.stats){
            Toast.makeText(LeaderboardActivity.this, "Stats/Submit", Toast.LENGTH_LONG).show();
            Intent save = new Intent(LeaderboardActivity.this, StatsActivity.class);
            save.putExtra("time", time);
            save.putExtra("cookies", cookies);
            save.putExtra("cookiesSpent", cookiesSpent);
            startActivity(save);
            return true;
        }
        else if(item.getItemId() == R.id.setReminder){
            Toast.makeText(LeaderboardActivity.this, "Setting reminder", Toast.LENGTH_LONG).show();
            GregorianCalendar gc = new GregorianCalendar();
            gc.add(Calendar.DATE, 1);
            String date = new SimpleDateFormat("yyyy-MM-dd").format(gc.getTime());
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date mDate = null;
            try {
                mDate = sdf.parse(date);
            } catch (ParseException e) {
                e.printStackTrace();
            }

            Calendar cal = Calendar.getInstance();
            cal.setTime(mDate);
            cal.set(Calendar.HOUR_OF_DAY, 8);
            cal.set(Calendar.MINUTE, 00);
            Intent intent = new Intent(Intent.ACTION_EDIT);
            intent.setType("vnd.android.cursor.item/event");
            intent.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, cal.getTimeInMillis());
            intent.putExtra(CalendarContract.EXTRA_EVENT_ALL_DAY, false);
            intent.putExtra(CalendarContract.Events.TITLE, "Play Cookie Tap!");
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            return true;
        }
        else if(item.getItemId() == R.id.reset){
            AlertDialog.Builder builder = new AlertDialog.Builder(LeaderboardActivity.this);
            builder.setTitle("Reset Progress?");
            builder.setMessage("Are you sure you want to reset? Progress won't automatically be added to the leaderboard");
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.dismiss();
                    Toast.makeText(LeaderboardActivity.this, "Resetting", Toast.LENGTH_LONG).show();
//                    SharedPreferences settings = getSharedPreferences("pref", 0);
//                    SharedPreferences.Editor editor = settings.edit();
//                    editor.clear();
//                    editor.apply();
                    SharedPreferences settings = getSharedPreferences("pref", 0);
                    SharedPreferences.Editor editor = settings.edit();
                    editor.clear();
                    editor.apply();
                    Intent reset = new Intent(LeaderboardActivity.this, SplashActivity.class);
                    startActivity(reset);
                }
            });
            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.dismiss();
                }
            });
            AlertDialog alert = builder.create();
            alert.show();
            return true;
        }
        else{
            return super.onOptionsItemSelected(item);
        }
    }
}